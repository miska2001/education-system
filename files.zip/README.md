# Latihan Lisan Individu — Malay A Literature HL

A practice and AI-feedback tool for IB Language A: Literature Individual Oral (Malay A HL). Students record live (or paste a transcript), and receive feedback marked against the four official IO criteria (A–D, 10 marks each).

**Live demo:** _add your GitHub Pages link here once published_

## How it works

- **Live Practice**: uses the browser's built-in speech recognition (Bahasa Melayu) to transcribe as the student speaks. Chrome or Edge only.
- **Paste Transcript**: for recordings made elsewhere — paste in a transcript instead.
- Transcript is sent directly from the student's browser to the Anthropic API and marked against the IB IO criteria.
- Feedback and history are stored **only in the browser making the request** (`localStorage`) — nothing is saved on a server.

## ⚠️ About the API key — please read

This tool calls the Anthropic API **directly from the browser** using a "bring your own key" pattern. That means:

- There is **no key embedded in this repository**. Do not add one to the code or commit one — anything committed to a public GitHub repo is visible to anyone.
- Each person using the tool pastes their **own** Anthropic API key into the "Kunci API" field at the top of the page. It's saved only in that browser's local storage and sent only to `api.anthropic.com`.
- Because the key lives in the browser, anyone with access to that browser's dev tools could technically read it back out. This is fine for a **trusted internal classroom tool** but is not the pattern to use for a public product — Anthropic explicitly flags this as a deliberate trade-off (the header is literally called `anthropic-dangerous-direct-browser-access`).
- **Recommended setup for a school**: create one API key on [console.anthropic.com](https://console.anthropic.com/settings/keys), set a **usage/spend limit** on it (Settings → Limits), and either:
  - share it only with yourself and paste it in when demonstrating to the class, or
  - accept that each student pastes the same shared key (simplest, but means every student's browser holds it — use a low spend cap), or
  - have each student who has their own Anthropic account use their own key (most secure, more setup).
- Rotate/delete the key from the console at any time if you suspect misuse.

## Hosting on GitHub Pages

1. Create a new **public** (or private, if your GitHub plan supports Pages on private repos) repository, e.g. `io-practice-tool`.
2. Add `index.html` (this file) to the repo root.
3. Go to **Settings → Pages** in the repo.
4. Under "Build and deployment", set **Source: Deploy from a branch**, branch `main`, folder `/ (root)`. Save.
5. Wait ~1 minute, then your tool will be live at `https://<your-username>.github.io/<repo-name>/`.
6. Share that link with students. Each student pastes their own (or the shared) API key on first use.

## Customising

- **Rubric / prompt**: edit the `systemPrompt` string inside the `<script>` tag to adjust marking emphasis, add examiner notes, or extend to other subjects (English B, Arabic B use a different IO criteria set — ask for a variant if needed).
- **Recognition language**: `recognition.lang = 'ms-MY'` — change if adapting for another Language A.
- **Styling**: CSS variables at the top of the `<style>` block control the colour palette and fonts.

## Limitations

- Speech recognition quality depends on the browser's engine and can misread literary/technical Malay vocabulary — the marking prompt is instructed to be lenient around obvious transcription artifacts, but a manual proofread before grading is recommended.
- This is a **formative practice aid**, not a substitute for teacher moderation against official IB standards.
- History is per-browser/device, not synced across devices.
